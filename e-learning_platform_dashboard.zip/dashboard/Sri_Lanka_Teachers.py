import streamlit as st
import pandas as pd
import altair as alt
from geopy.geocoders import Nominatim
geolocator = Nominatim(user_agent='default_user_agent')



st.set_page_config(page_title='ELP - Teachers', page_icon=None, layout="wide")
# st.sidebar.header("Company name")

st.title("Teachers Information")

# CSV teachers data File
file_path = './data/data_21_03_2024.csv'


# Tabs
tab1, tab2, tab3, tab4 = st.tabs(["Subject Wise", "Location wise", "Class Type", "Map"])

with tab1:

    df = pd.read_csv(file_path, engine='python', usecols=["Tuter Name", "Grade", "location", "Class Type"])
    df.drop_duplicates(subset="Tuter Name")
    dataSet = df.groupby(["Grade"])["Class Type"].count().reset_index(name="count")
    dataSet2 = dataSet.sort_values(by='count', ascending=False)

    st.title("Subject Wise")
    col1, col2 = st.columns([1, 2])

    with col1:
       st.header("Data Display")
       st.write(dataSet2)

    with col2:
       st.header("Graph")

       st.write(alt.Chart(dataSet2).mark_bar().encode(
           x=alt.X('Grade', sort=None),
           y='count',
       ))



with tab2:

    locationdf = pd.read_csv(file_path, engine='python', usecols=["Grade", "location", "Class Type"])
    locationdataSet = locationdf.groupby(["location"])["Class Type"].count().reset_index(name="count")
    locationdataSet2 = locationdataSet.sort_values(by='count', ascending=False)

    st.title("Location Wise")
    col1, col2 = st.columns([1, 2])

    with col1:
       st.header("Data Display")
       st.write(locationdataSet2)

    with col2:
       st.header("Graph")

       st.write(alt.Chart(locationdataSet2).mark_bar().encode(
           x=alt.X('location', sort=None),
           y='count',
       ))




with tab3:

    classtypedf = pd.read_csv(file_path, engine='python', usecols=["Grade", "location", "Class Type"])
    classtypedataSet = classtypedf.groupby(["Class Type"])["Class Type"].count().reset_index(name="count")
    classtypedataSet2 = classtypedataSet.sort_values(by='count', ascending=False)

    st.title("Class Type")
    col1, col2 = st.columns([1, 2])

    with col1:
       st.header("Data Display")
       st.write(classtypedataSet2)

    with col2:
       st.header("Graph")

       st.write(alt.Chart(classtypedataSet2).mark_bar().encode(
           x=alt.X('Class Type', sort=None),
           y='count',
       ))



def getLocation(location):

    if location == 'All Island':
        latitude = ''
        longitude = ''
    else:
        state = location.replace(' District', '')
        location = geolocator.geocode(state)

        if location == None:
            latitude = ''
            longitude = ''
        else:
            latitude = location.latitude
            longitude = location.longitude

    return latitude, longitude


with tab4:

    locationdf = pd.read_csv(file_path, engine='python', usecols=["Grade", "location", "Class Type"])
    locationdataSet = locationdf.groupby(["location"])["Class Type"].count().reset_index(name="count")
    locationdataSet2 = locationdataSet.sort_values(by='count', ascending=False)

    # location_list = locationdataSet2['location'].tolist()

    st.title("Location Wise")

    col1, col2 = st.columns([2, 1])

    with col1:
        st.header("Map")

        i=0
        glData = []
        for index, row in locationdataSet2.iterrows():
            latitude, longitude = getLocation(row['location'])

            if latitude != '' and longitude != '':
                glData.append({
                    "count": int(row['count']),
                    "location": row['location'],
                    "latitude": latitude,
                    "longitude": longitude
                })

        locationDatamaps = pd.DataFrame(glData)

        st.map(locationDatamaps,
           latitude='latitude',
           longitude='longitude',
           size='count',
           zoom =6,
           # color=np.random.rand(21, 4).tolist()
           )


    with col2:
        st.header("Map Details")

        st.write(locationDatamaps)











