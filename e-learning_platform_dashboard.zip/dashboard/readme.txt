==== Welcome ====

Env Setup:
We needs to install bellow package to run this project after python 3.12 env setup

pip install streamlit
pip install pandas
pip install altair
pip install geolocator
pip install sklearn
pip install matplotlib
pip install Nominatim

Data Files:
All data files uploaded in the 'data' folder

Main page:
Sri_Lanka_Teachers.py this file is the main file for the project, all other sub pages are in the 'pages'folder
after setup environment you needs to run bellow command in the termminal to run the application

python3 -m streamlit run ./Sri_Lanka_Teachers.py


==== Good Luck =====

