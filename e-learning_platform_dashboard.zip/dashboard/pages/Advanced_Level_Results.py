import streamlit as st
import pandas as pd

from geopy.geocoders import Nominatim
geolocator = Nominatim(user_agent='default_user_agent')



st.set_page_config(page_title='ELP - Results', page_icon=None, layout="wide")
# st.sidebar.header("Company name")

st.title("A/L Results")

# CSV teachers data File
file_path = './data/alresults.csv'



# Tabs
tab1, tab2, tab3, tab4 = st.tabs(["Results Summary", "Participation Rate", "Passing Rate", 'Teachers Ratio for Exam Faced Students'])

with tab1:

    # get needed data from csv to repracent data in geographically
    df = pd.read_csv(file_path, engine='python', usecols=["city", "faced", "pass"])
    dataSet2 = df.sort_values(by='faced', ascending=False)
    dataSet2['rate %'] = (dataSet2['pass'] / dataSet2['faced'])*100


    st.title("Passing Rate")
    col1, col2 = st.columns([1, 2])

    with col1:
       st.header("District Wise Rate")
       st.write(dataSet2)

    with col2:
       st.header("District Wise Graph")

       chart_data = pd.DataFrame(
           {"City": dataSet2['city'].tolist(), "Faced": dataSet2['faced'].tolist(), "Pass": dataSet2['pass'].tolist()}
       )

       st.bar_chart(
           chart_data, x="City", y=["Faced", "Pass"], color=["#FF0000", "#0000FF"]  # Optional
       )


def getLocation(location):

    if location == 'All Island':
        latitude = ''
        longitude = ''
    else:
        state = location.replace(' District', '')
        location = geolocator.geocode(state)

        if location == None:
            latitude = ''
            longitude = ''
        else:
            latitude = location.latitude
            longitude = location.longitude

    return latitude, longitude





with tab2:
    df = pd.read_csv(file_path, engine='python', usecols=["city", "faced", "pass"])
    dataSet2 = df.sort_values(by='faced', ascending=False)

    col1, col2 = st.columns([2, 1])

    with col1:
        st.header("Map")

        i = 0
        glData = []
        for index, row in dataSet2.iterrows():
            latitude, longitude = getLocation(row['city'])

            if latitude != '' and longitude != '':
                glData.append({
                    "faced": int(row['faced']),
                    "location": row['city'],
                    "latitude": latitude,
                    "longitude": longitude
                })

        locationDatamaps = pd.DataFrame(glData)

        st.map(locationDatamaps,
           latitude='latitude',
           longitude='longitude',
           size='faced',
           zoom=7,
           # color=np.random.rand(21, 4).tolist()
           )

    with col2:
        st.header("Map Details")

        st.write(locationDatamaps)



with tab3:
    df = pd.read_csv(file_path, engine='python', usecols=["city", "faced", "pass"])
    dataSet3 = df.sort_values(by='pass', ascending=False)

    col1, col2 = st.columns([2, 1])

    with col1:
        st.header("Map")

        i = 0
        glData2 = []
        for index, row in dataSet3.iterrows():
            latitude, longitude = getLocation(row['city'])

            if latitude != '' and longitude != '':
                glData2.append({
                    "pass": int(row['pass']),
                    "location": row['city'],
                    "latitude": latitude,
                    "longitude": longitude
                })

        locationDatamaps2 = pd.DataFrame(glData2)

        st.map(locationDatamaps2,
           latitude='latitude',
           longitude='longitude',
           size='pass',
           zoom=7,
           # color=np.random.rand(21, 4).tolist()
           )

    with col2:
        st.header("Map Details")

        st.write(locationDatamaps2)





with tab4:
    dfx = pd.read_csv(file_path, engine='python', usecols=["city", "faced"])
    dataSet3 = dfx.sort_values(by='faced', ascending=False)
    dataSet3['No_of_Teachers'] = round(dataSet2['faced'] / float(18.48))

    numberx = int(max(dataSet3['No_of_Teachers']))


    col1, col2 = st.columns([1, 2])

    with col1:
        st.header("District wise Teachers Ratio")
        st.write(dataSet3)

    with col2:
        st.header("District wise Teachers Ratio Graph")

        chart_data = pd.DataFrame(
            {"City": dataSet3['city'].tolist(), "Faced": dataSet3['faced'].tolist(),
             "No_of_Teachers": dataSet3['No_of_Teachers'].tolist()}
        )

        st.bar_chart(
            chart_data, x="City", y=["Faced", "No_of_Teachers"], color=["#FF0000", "#0000FF"]  # Optional
        )