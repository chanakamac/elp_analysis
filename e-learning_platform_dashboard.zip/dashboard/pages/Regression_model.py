import streamlit as st
from geopy.geocoders import Nominatim
geolocator = Nominatim(user_agent='default_user_agent')
import altair as alt

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
import matplotlib.pyplot as plt
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer


st.set_page_config(page_title='ELP - Regression Model', page_icon=None, layout="wide")

st.title("Regression Model")

# CSV teachers data File
file_path = './data/alresults.csv'
file_path2 = './data/data_21_03_2024.csv'





locationdf = pd.read_csv(file_path2, engine='python', usecols=["Grade", "location", "Class Type"])
glData2 = []
for index, row in locationdf.iterrows():
    if ' A/L ' in row['Grade'] and row['location'] != 'All Island':
        row['city'] = row['location'].replace(' District', '')
        row['Grade'] = 'A/L'
        glData2.append(row)

locData = pd.DataFrame(glData2)

locationdataSet = locData.groupby(["city", "Grade"])["Class Type"].count().reset_index(name="count")
locationdataSet2 = locationdataSet.sort_values(by='count', ascending=False)



df = pd.read_csv(file_path, engine='python', usecols=["city", "faced", "pass"])
dataSet2 = df.sort_values(by='faced', ascending=False)
dataSet2['rate'] = (dataSet2['pass'] / dataSet2['faced'])*100

data = locationdataSet2.merge(dataSet2, left_on='city', right_on='city')





col1, col2, col3 = st.columns([1, 1, 1])

with col1:
   st.header("Data Display")
   st.write(data)


with col2:
    # Load data
    data.dropna(inplace=True)
    # Data preprocessing

    X = data[['city', 'rate', 'count']]
    y = data['count']

    column_transformer = ColumnTransformer([('encoder', OneHotEncoder(), [0])], remainder='passthrough')
    X_encoded = column_transformer.fit_transform(X)


    # Split data into train and test sets
    X_train, X_test, y_train, y_test = train_test_split(X_encoded, y, test_size=0.2, random_state=42)

    # Model selection and training
    model = LinearRegression()
    model.fit(X_train, y_train)

    # Model evaluation
    y_pred = model.predict(X_test)
    mse = mean_squared_error(y_test, y_pred)

    st.write('Mean Squared Error: ')
    st.write(mse)


with col3:

    def teacherPassrate(studentsPassed, studentsPerTeacher, teachers):
        pass_rate = studentsPassed / (studentsPerTeacher * teachers)
        return pass_rate

    studentsPassed = 80
    studentsPerTeacher = 102
    teachers = 10

    pass_rate = teacherPassrate(studentsPassed, studentsPerTeacher, teachers)
    st.write("Teacher Pass Rate:", pass_rate)




