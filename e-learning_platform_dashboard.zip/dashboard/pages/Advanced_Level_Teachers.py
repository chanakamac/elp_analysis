import streamlit as st
import pandas as pd
import altair as alt

from geopy.geocoders import Nominatim
geolocator = Nominatim(user_agent='default_user_agent')


st.set_page_config(page_title='ELP - Teachers', page_icon=None, layout="wide")
# st.sidebar.header("Company name")

st.title("Sri Lanka A/L Teachers In the system")

# CSV teachers data File
file_path = './data/data_21_03_2024.csv'



# Tabs
tab1, tab2, tab3 = st.tabs(["A/L Subject Categories", "Locations", "Class Type"])

with tab1:

    df = pd.read_csv(file_path, engine='python', usecols=["Grade", "location", "Class Type"])
    dataSet = df.groupby(["Grade"])["Class Type"].count().reset_index(name="count")
    dataSet2 = dataSet.sort_values(by='count', ascending=False)

    glData = []
    for index, row in dataSet2.iterrows():

        if ' A/L ' in row['Grade']:
            glData.append(row)

    locationDatamaps = pd.DataFrame(glData)


    col1, col2 = st.columns([1, 2])

    with col1:
       st.header("Advance Level Teachers")
       st.write('Here we have all teachers who are teaching A/L subjects in Sri Lanka. In Sri Lanka we have '+str(locationDatamaps['count'].sum())+' Teachers all over the country.')
       st.write(locationDatamaps)

    with col2:
       st.header("Graph")

       st.write(alt.Chart(locationDatamaps).mark_bar().encode(
           x=alt.X('Grade', sort=None),
           y='count',
       ))



with tab2:

    locationdf = pd.read_csv(file_path, engine='python', usecols=["Grade", "location", "Class Type"])
    glData2 = []
    for index, row in locationdf.iterrows():
        if ' A/L ' in row['Grade'] and row['location'] != 'All Island':
            row['Grade'] = 'A/L'
            glData2.append(row)

    locData = pd.DataFrame(glData2)


    locationdataSet = locData.groupby(["location", "Grade"])["Class Type"].count().reset_index(name="count")
    locationdataSet2 = locationdataSet.sort_values(by='count', ascending=False)


    st.title("District Wise")
    col1, col2, col3 = st.columns([1, 1, 1])

    with col1:
       st.header("Data Display")
       st.write(locationdataSet2)


    with col2:
       st.header("Graph")

       st.write(alt.Chart(locationdataSet2).mark_bar().encode(
           x=alt.X('location', sort=None),
           y='count',
       ))


    def getLocation(location):

        if location == 'All Island':
            latitude = ''
            longitude = ''
        else:
            state = location.replace(' District', '')
            location = geolocator.geocode(state)

            if location == None:
                latitude = ''
                longitude = ''
            else:
                latitude = location.latitude
                longitude = location.longitude

        return latitude, longitude


with col3:
    glData = []
    for index, row in locationdataSet2.iterrows():
        latitude, longitude = getLocation(row['location'])

        if latitude != '' and longitude != '':
            glData.append({
                "count": int(row['count']),
                "location": row['location'],
                "latitude": latitude,
                "longitude": longitude
            })

    locationDatamaps = pd.DataFrame(glData)

    st.map(locationDatamaps,
           latitude='latitude',
           longitude='longitude',
           size='count',
           zoom=6,
           # color=np.random.rand(21, 4).tolist()
           )






with tab3:
    locationdf2 = pd.read_csv(file_path, engine='python', usecols=["Grade", "location", "Class Type"])
    glData3 = []
    for index, row in locationdf2.iterrows():
        if ' A/L ' in row['Grade'] and row['location'] != 'All Island':
            row['Grade'] = 'A/L'
            glData3.append(row)

    locData2 = pd.DataFrame(glData3)

    locationdataSet2 = locData2.groupby(["location", "Class Type"])["Class Type"].count().reset_index(name="count")
    locationdataSet3 = locationdataSet2.sort_values(by='count', ascending=False)

    st.title("District Wise")
    col1, col2 = st.columns([1, 2])

    with col1:
        st.header("Data Display")
        st.write(locationdataSet3)

    with col2:
        st.header("Graph")

        st.write(alt.Chart(locationdataSet3).mark_bar().encode(
            x=alt.X('location', sort=None),
            y='count',
        ))

